from flask import Flask, render_template, request
import requests
import smtplib

# Constants
SENDER_EMAIL = "1419goku@gmail.com"
EMAIL_PASSWORD = "musicisthebest"
EMAIL_SMTP = "smtp.gmail.com"

app = Flask(__name__)

BLOG_URL = "https://api.npoint.io/5abcca6f4e39b4955965"
all_posts = requests.get(BLOG_URL).json()

@app.route('/')
def home():
  return render_template('index.html', posts=all_posts, title_name="Home")

@app.route('/about')
def about():
  return render_template('about.html', title_name="About")

@app.route('/contact', methods=['POST', 'GET'])
def contact():
  if request.method == "POST":
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    message_text = request.form['message']
    
    try:
      server = smtplib.SMTP(EMAIL_SMTP)
      server.starttls() # Secure the connection
      server.login(SENDER_EMAIL, EMAIL_PASSWORD)
      message = "Subject: Email from Edgar's Blog Contact form\n\n"
      message += f"Name: {name}\n"
      message += f"Email: {email}\n"
      message += f"Phone: {phone}\n"
      message += f"Message:\n{message_text}\nSent from Contact Form"
      server.sendmail(SENDER_EMAIL, SENDER_EMAIL, message)
    except Exception as e:
      # Print any error messages to stdout
      print(e)
    finally:
      server.quit()
    
    return render_template('contact.html', title_name="Contact Me", heading_text="Successfully sent message")
  else:
    return render_template('contact.html', title_name="Contact Me", heading_text="Contact Me")

@app.route('/post/<int:id>')
def get_post(id):
  requested_post = None
  for post in all_posts:
    if id == post['id']:
      requested_post = post
  return render_template('post.html', post=requested_post, title_name=requested_post['title'])

app.run(debug=True)
